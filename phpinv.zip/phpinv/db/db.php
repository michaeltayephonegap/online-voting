
<?php//Michael taye 
//Contact:-0916182957
?>

<?php 
error_reporting(0);
$con = mysql_connect('localhost','root','') or die('can not connect to server');
if($con)
{
	mysql_select_db('prime_ims',$con) or die('can not select database');
}
