<?php//Michael taye 
//Contact:-0916182957
?>


<?php 


  include('db/db.php');
  if(isset($_POST['order']))
  {
    $invoicenum = $_POST['invoicenum'];
    $order_name = $_POST['order_name'];
    $location   = $_POST['location'];
    $date_order = $_POST['date_order'];
    $due_date = $_POST['due_date'];
    $status="UNPAID";
    mysql_query("INSERT INTO tborder(invoicenum,order_name,location,date_order,due_date,status)
    values('$invoicenum','$order_name','$location','$date_order','$due_date','$status')");
    $id = mysql_insert_id();
    if($id > 0)
    {
      for($i=0;$i<count($_POST['product_name']);$i++)
      {
        $product_name = $_POST['product_name'][$i];
        $invoicenum = $_POST['invoicenum'];
        $quantity = $_POST['quantity'][$i];
        $price = $_POST['price'][$i];
        $amount = $_POST['amount'][$i];
        $Status="UNPAID";

        mysql_query("INSERT INTO tborderdetail(order_id,product_name,invoicenum,quantity,price,amount,Status) 
              values('$order_id','$product_name','$invoicenum','$quantity','$price','$amount','$Status')");
      }
    }
  } 




?><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="c.css" />
<link href="css/print1.css" rel="stylesheet" type="text/css" media="print">

<style type="text/css">
<!--
.style1 {font-family: Georgia, "Times New Roman", Times, serif}
.style2 {color: #000000}
-->
</style>

<div class="empty">
<title id="print">Prime Software IMS</title>
</div>
<style type="text/css">
H1{color:RED
}
P {text-align:right;}
p1 {text-decoration:blink;}
H3{text-align:right;}
/*#td1{
background-color: #CCCCCC;

}*/
#prime {
right:300px;
}
#unpaid {border: 1px solid;
color:#FF0000;
position:absolute;
right: 150px;
}
#primepo {
}
</style>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body 
    
<div class="container" style="background-color:#efefef">
  <form action="" method="post">  
    <table class="table">
    	<tr>
        <img src="Logo.png" width="250" height="150" />
        </tr>
       <BR>
       	<tr> 
 </tr><td id="td1">
        <h4><label>Invoice  #  <?php echo $_POST['invoicenum'];?></label><br><br>
    		<label>Invoice Date   <?php echo $_POST['date_order'];?></label><br>
        <label>Due Date        <?php echo $_POST['due_date'];?></label>
                </h4>  
         	    </td>
         	     <td>
<div class="style2" id="primepo">
         	       <P>
                    <big><strong><span class="style1">PRIME SOFTWARE PLC</span></strong></big><strong><br />
                    </strong>Mexico K/KARE Bldgs<br />
                    4th Floor Suite 48/2<br />Addis Ababa<br />Ethiopia<br/>
        Tel:-0115 575050<br />
        Tel:-+251 913798523</P>
         	    <!--input type="text" class="form-control" name="location" value="Phnom Penh"-->
                <br><br>
              </div>
                <div id="unpaid">
                <BIG><BIG><h1>UNPAID</h1></BIG></BIG>
                </div>
         	</td>
    	</tr>
      <div id="print">
    		<td>
              
              
               <label> Invoice To <br>
              <?php echo 'Name:-'. $_POST['order_name'];echo '<br>';?>
              <?php echo 'Address:-'. $_POST['location'];echo '<br>';?>
            </label>
                
                
         	    <!--input type="text" class="form-control" name="order_name"-->
              
              
    		</td>

    	</tr>
    </table>
    </div>
    <hr style="border:1px dashed black">
    <table class="table table-hover">
    	<thead>
    		<tr>
    			<th>ProductName</th>
    			<th>Quantity</th>
    			<th>Price</th>
    			<th>Amount</th>
    		
    			
                <label>
<div class="empty">
<th>  <a href="#" class="btn btn-primary"  onClick="window.print()" id="print" ><i class="fa fa-print"></i>Print Logs</a></th> 
<th>  <a href="#" class="btn btn-primary" id="print"  ><i class="fa fa-print"></i>Genrate PDF</a></th> 
<th>  <a href="index.php" class="btn btn-primary" window.location=\'index.php\'  id="print" ><i class="fa fa-print"></i>Back To Edit</a></th>  

                </label> 
               
    		</tr>
    	</thead>
    	<tbody class="details">
    		  <tr>
    		  	   <td><input type="text"  name="product_name[]" class="form-control product_name" readonly="readonly"></td>
    		  	   <td><input type="text"  name="quantity[]" class="form-control quantity" readonly="readonly"></td>
    		  	   <td><input type="text" name="price[]" class="form-control price" readonly="readonly"></td>
    		  	   <td><input type="text"  name="amount[]" class="form-control amount" readonly="readonly"></td>
                   
    		  	   
    		  </tr>
    	</tbody>
    	<tfoot>
    		<tr>   
    		    <td></td>
    		    <td></td>
    		    <td></td> 		   
    			<td>
    				<label>Sub Total</label>
    				<input type="text" name="subtotal" class="subtotal form-control" readonly="readonly">
    			
    				<label>Get Pay</label>
    				<input type="text" name="pay" class="pay form-control" readonly="readonly">
    			
    				<label>Return</label>
    				<input type="text" name="return" class="return form-control" readonly="readonly"><br/>
    			
    			</td>
    		</tr>
    	</tfoot>
    </table>
 
  </form>
   <hr style="border:1px dashed black">
 </div>
    </div>
</body>
</html>

<script type="text/javascript">
    function total()
    {
       var gg = 0;
       $('.amount').each(function(i,e){
       		var amt = $(this).val()-0;
       		gg += amt;
       	});
       $('.subtotal').val(gg);
    }


	$(function(){


		// add new row 
		$('.add').click(function(){
			var tr = '<tr>'+
		    		  	   '<td><input type="text" name="product_name[]" class="form-control product_name"></td>'+
		    		  	   '<td><input type="text" name="quantity[]" class="form-control quantity"></td>'+
		    		  	   '<td><input type="text" name="price[]" class="form-control price"></td>'+
		    		  	   '<td><input type="text" name="amount[]" class="form-control amount"></td>'+
		    		  	   '<td><input type="button"  class="btn btn-danger remove" value="Remove"></td>'+
		    		  '</tr>';
		  $('.details').append(tr);
		});
		// end 

		// total amount 
		$('.details').delegate('.quantity,.price','keyup',function(){
			var tr = $(this).parent().parent();
			var price = tr.find('.price').val();
			var qty   = tr.find('.quantity').val();
			var amount = price * qty;
			tr.find('.amount').val(amount);
			total();
		});
		// end 

		// delete row 
		$('.details').delegate('.remove','click',function(){
				var con = confirm("Do you want to remove Row it ?");
				if(con)
				{
					$(this).parent().parent().remove();
					total();
				}

		});
		// end 


	    //get pay
		$('.pay').change(function(){
			var subtotal = $('.subtotal').val()-0;
			var get      = $(this).val()-0;
			$('.return').val(get - subtotal);
		});
		// end 
	});
</script>
