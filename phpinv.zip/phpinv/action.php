<?php 
  include('db/db.php');
  if(isset($_POST['order']))
  {
    $invoicenum = $_POST['invoicenum'];
    $order_name = $_POST['order_name'];
    $location   = $_POST['location'];
    $date_order = $_POST['date_order'];
    $due_date = $_POST['due_date'];
    $status="UNPAID";
    mysql_query("INSERT INTO tborder(invoicenum,order_name,location,date_order,due_date,status)
    values('$invoicenum','$order_name','$location','$date_order','$due_date','$status')");
    $id = mysql_insert_id();
    if($id > 0)
    {
      for($i=0;$i<count($_POST['product_name']);$i++)
      {
        $product_name = $_POST['product_name'][$i];
        $invoicenum = $_POST['invoicenum'];
        $quantity = $_POST['quantity'][$i];
        $price = $_POST['price'][$i];
        $amount = $_POST['amount'][$i];
        $Status="UNPAID";

        mysql_query("INSERT INTO tborderdetail(order_id,product_name,invoicenum,quantity,price,amount,Status) 
              values('$order_id','$product_name','$invoicenum','$quantity','$price','$amount','$Status')");
      }
    }
  } 


  echo   '<script type="text/javascript">alert("Invoice Record Succesfully");window.location=\'print.php\';</script>';

?>

<?php//Michael taye 
//Contact:-0916182957
?>
