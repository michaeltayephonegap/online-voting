<?php//Michael taye 
//Contact:-0916182957
?>

<html>
<head>
  <title> PRIME Invoice</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery.js"></script>
</head>
<body>
<!--?php 
  include('db/db.php');
  if(isset($_POST['order']))
  {
    $invoicenum = $_POST['invoicenum'];
    $order_name = $_POST['order_name'];
    $location   = $_POST['location'];
    $date_order = $_POST['date_order'];
    $due_date = $_POST['due_date'];
    $Status="UNPAID";
    mysql_query("INSERT INTO tborder(invoicenum,order_name,location,date_order,due_date,Status)
     values('$invoicenum','$order_name','$location','$date_order','$due_date','$Status')");
    $id = mysql_insert_id();
    if($id > 0)
    {
      for($i=0;$i<count($_POST['product_name']);$i++)
      {
        $product_name = $_POST['product_name'][$i];
        $invoicenum = $_POST['invoicenum'];
        $quantity     = $_POST['quantity'][$i];
        $price        = $_POST['price'][$i];
        $amount       = $_POST['amount'][$i];
        $Status="UNPAID";

        mysql_query("INSERT INTO tborderdetail(order_id,product_name,invoicenum,quantity,price,amount,Status) 
              values('$order_id','$product_name','$invoicenum','$quantity','$price','$amount','$Status')");
      }
    }
  } 

  
?-->
 <div class="container" style="background-color:#efefef">
  <center><h2>Prime Software</h2></center>
  <form action="print.php" method="post">  
    <table class="table">
      <!--Fro genrate random invoice number-->
      <?php 
$today = date("Y");
$rand = strtoupper(substr(uniqid(sha1(time())),0,5));
  if (isset($_POST['generate']))
  {
  echo "#&nbsp;";
    echo $unique = $today . $rand;    
  }
 ?>
          <tr>
          <td>
              <label>Invoice Number #</label>
               <input type="text" name="invoicenum" class="btn btn-primary" value="<?php  echo $rand;?>" size="10" readonly>    
         </td>
         <br>
         <td>
         	</td>
         	<td><label>OrderName</label>
            <input type="text" class="form-control" name="order_name" placeholder="Enter Client name">
         	    <label>Location</label>
         	    <input type="text" class="form-control" name="location" value="" placeholder="Enter your location">
         	</td>
    	</tr>
    	<tr>
    		<td>
<?PHP
$today = date("d-m-y");
?>

<br><br>
    			<label>Date Order</label>
          <input  class="btn btn-primary" name="date_order" value="<?php echo  $today;?>" readonly size="20">
          <br><br>
          <label>Due Date</label>
    			<input type="date" class="form-control" name="due_date" value="" placeholder="Enter Due Date">
    		</td>

    	</tr>
    </table>
    <hr style="border:1px dashed black">
    <table class="table table-hover">
    	<thead>
    		<tr>
    			<th>ProductName</th>
    			<th>Quantity</th>
    			<th>Price</th>
    			<th>Amount</th>
    			<th>Remove</th>
    			<th><input type="button"  class="btn btn-primary add" value="+ Add Service"></th>
                <th><a href="print.php" class="btn btn-primary add" target="_blank">Print</a></th>
    		</tr>
    	</thead>
    	<tbody class="details">
    		  <tr>
    		  	   <td><input type="text" name="product_name[]" class="form-control product_name"></td> 
               <td><input type="text" name="quantity[]" class="form-control quantity"></td>
               <td><input name="price" type="text" class="form-control price oN"  id="price" size="10" onKeyUp="changeTax()"></td>
               <td><input type="text" name="amount[]" class="form-control amount"></td>
               <td><input type="button"  class="btn btn-danger remove" value="Remove"></td>
    		  </tr>
    	</tbody>
    	<tfoot>
    		<tr>   
    		    <td></td>
    		    <td></td>
            <td></td> 		   
    			<td>
            <label>Tax</label><input name="tax" class="tax form-control" type="text"  id="tax" size="10" readonly>
    				<label>Sub Total</label>
    				<input type="text" name="subtotal" class="subtotal form-control" readonly>
            <label>Get Pay</label>
    				<input type="text" name="pay" class="pay form-control" >
            <label>Return</label>
    				<input type="text" name="return" class="return form-control" readonly><br/>
    				<input type="submit" class="btn btn-primary"  name="order" target="_blank" value="Order Now">
          
    			</td>
    		</tr>
    	</tfoot>
    </table>
  </form>
 </div>
</body>
</html>

<script type="text/javascript">
    

    function total()
    {
       var gg = 0;
       $('.amount').each(function(i,e){
       		var amt = $(this).val()-0;
       		gg += amt;
       	});
       $('.subtotal').val(gg);
    }


	$(function(){


		// add new row 
		$('.add').click(function(){
			var tr = '<tr>'+
		    		  	   '<td><input type="text" name="product_name[]" class="form-control product_name"></td>'+
		    		  	   '<td><input type="text" name="quantity[]" class="form-control quantity"></td>'+
		    		  	   '<td><input type="text" name="price[]" class="form-control price"></td>'+
		    		  	   '<td><input type="text" name="amount[]" class="form-control amount"></td>'+
		    		  	   '<td><input type="button"  class="btn btn-danger remove" value="Remove"></td>'+
		    		  '</tr>';
		  $('.details').append(tr);
		});
		// end 

		// total amount 
		$('.details').delegate('.quantity,.price','keyup',function(){
			var tr = $(this).parent().parent();
			var price = tr.find('.price').val();
			var qty   = tr.find('.quantity').val();
			var amount = price * qty;
			tr.find('.amount').val(amount);
			total();
		});
		// end 

/*/$('details').delegate('price[]',function(){
//var price[] $(this).parent().parent();
var price[] = document.getElementById('price[]').value;
var np = Number(price[]);
var tax =0.15* np;

document.getElementById('tax').value =tax;
document.getElementById('total').value =(tax)+(np);

});*/

		// delete row 
		$('.details').delegate('.remove','click',function(){
				var con = confirm("Do you want to remove it ?");
				if(con)
				{
					$(this).parent().parent().remove();
					total();
				}

		});
		// end 



		//get pay
		$('.pay').change(function(){
			var subtotal = $('.subtotal').val()-0;
			var get      = $(this).val()-0;
			$('.return').val(get - subtotal);
		});
		// end 
	});
</script>
            
           

              <script type="text/javascript">

                 // for updating the tax while writing the price .


                   function changeTax(){

                      var price[] = document.getElementById("price[]").value;
                      
                      var np = Number(price[]);
                      var tax =  0.15 * np;

                      

                      <!-- how to diferenciate  concatinate nad plus sign-->

                      document.getElementById("tax").value = tax;
                      document.getElementById("total").value = (tax) + (np);
                   }
              </script>
                         <script>
        $(function() {
              
         });
         </script>