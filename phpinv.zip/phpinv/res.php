<table align="center" border="1" cellspacing="0" width="500">
                    <tr>
                    <th>order_name</th>
                    <th>location</th>
               
                    </tr>
                    <?php
                    include('db/db.php');
                    if(isset($_GET['search']))
                    {
                        $query = $_GET['query'];
                        $sql = "select * from tborder where order_name like '%$query%' or location like '%$query%'";
                       // $sql = "select * from tborder where firstName like '%$query%' or lastName like '%$query%'";
                        $result = $conn->query($sql);
                        if($result->num_rows > 0){
                            while($row1 = $result->fetch_array()){
                                $order_name = $row1['order_name'];
                                $location = $row1['location'];
        
                        ?>
                        <tr>
                            <td align="center"><?php echo $order_name;?></td>
                            <td align="center"><?php echo $location;?></td>
                           
                        </tr>
                        <?php
                    
                            }

                        }else{
                            echo "<center>No records</center>";
                        }
                    }
                $conn->close();
                ?>
                </table>