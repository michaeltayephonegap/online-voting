<?php//Michael taye 
//Contact:-0916182957
?>

Drop Database `prime_ims`;
use Database `prime_ims`;
-- Database: `sample_invoice`
---- ----------------------------------------------------------
-- Table structure for table `tborder`--
Drop table `tborder`;
CREATE TABLE `tborder` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `invoicenum` varchar(65) NOT NULL,
  `order_name` varchar(65) NOT NULL,
  `location` varchar(65) NOT NULL,
  `date_order` date NOT NULL,
  `due_date` date NOT NULL,
   `status` varchar(10) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `tborder`
--


-- --------------------------------------------------------

--
-- Table structure for table `tborderdetail`
--
Drop table `tborderdetail`;
CREATE TABLE `tborderdetail` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoicenum` varchar(65) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` varchar(20) NOT NULL,
  `amount` varchar(40) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tborderdetail`
--
