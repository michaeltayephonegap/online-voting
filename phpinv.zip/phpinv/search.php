<?php  ?>

<form action="res.php" method="get" ecntype="multipart/data-form">
                        <table align="center">
                            <tr>
                                <td>Search: <input type="text" name="query"><input type="submit" value="Search" name="search"></td>
                            </tr>
                        </table>
                </form>
                