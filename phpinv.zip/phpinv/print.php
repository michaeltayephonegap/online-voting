
<?php//Michael taye 
//Contact:-0916182957
?>


<?php 


  include('db/db.php');
  if(isset($_POST['order']))
  {
    $invoicenum = $_POST['invoicenum'];
    $order_name = $_POST['order_name'];
    $location   = $_POST['location'];
    $date_order = $_POST['date_order'];
    $due_date = $_POST['due_date'];
    $status="UNPAID";
    mysql_query("INSERT INTO tborder(invoicenum,order_name,location,date_order,due_date,status)
    values('$invoicenum','$order_name','$location','$date_order','$due_date','$status')");
    $id = mysql_insert_id();
    if($id > 0)
    {
      for($i=0;$i<count($_POST['product_name']);$i++)
      {
        $product_name = $_POST['product_name'][$i];
        $invoicenum = $_POST['invoicenum'];
        $quantity = $_POST['quantity'][$i];
        $price = $_POST['price'][$i];
        $amount = $_POST['amount'][$i];
        $Status="UNPAID";

        mysql_query("INSERT INTO tborderdetail(order_id,product_name,invoicenum,quantity,price,amount,Status) 
              values('$order_id','$product_name','$invoicenum','$quantity','$price','$amount','$Status')");
      }
    }
  } 




?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>A simple, clean, and responsive HTML invoice template</title>
    
    <style>
    .invoice-box{
        max-width:800px;
        margin:auto;
        padding:30px;
        border:1px solid #eee;
        box-shadow:0 0 10px rgba(0, 0, 0, .15);
        font-size:16px;
        line-height:24px;
        font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color:#555;
    }
    
	#unpaid {
color:#FF0000;

}
    .invoice-box table{
        width:100%;
        line-height:inherit;
        text-align:left;
    }
    
    .invoice-box table td{
        padding:5px;
        vertical-align:top;
    }
    
    .invoice-box table tr td:nth-child(2){
        text-align:right;
    }
    
    .invoice-box table tr.top table td{
        padding-bottom:20px;
    }
    
    .invoice-box table tr.top table td.title{
        font-size:45px;
        line-height:45px;
        color:#333;
    }
    
    .invoice-box table tr.information table td{
        padding-bottom:40px;
    }
    
    .invoice-box table tr.heading td{
        background:#eee;
        border-bottom:1px solid #ddd;
        font-weight:bold;
    }
    
    .invoice-box table tr.details td{
        padding-bottom:20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom:1px solid #eee;
    }
    
    .invoice-box table tr.item.last td{
        border-bottom:none;
    }
    
    .invoice-box table tr.total td:nth-child(2){
        border-top:2px solid #eee;
        font-weight:bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td{
            width:100%;
            display:block;
            text-align:center;
        }
        
        .invoice-box table tr.information table td{
            width:100%;
            display:block;
            text-align:center;
        }
    }
    </style>
</head>

<body>
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                                 <img src="Logo.png" width="250" height="150"  style="width:100%; max-width:300px;">
                            </td>
                            
                            <td>
                                  <big><strong><span class="style1">PRIME SOFTWARE PLC</span></strong></big><strong><br />
                               </strong>Mexico K/KARE Bldgs<br />
                    4th Floor Suite 48/2<br />Addis Ababa<br />Ethiopia<br/>
        Tel:-0115 575050<br />
        Tel:-+251 913798523</P>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td >
                               Invoice #: <?php echo $_POST['invoicenum'];?><br>
                                Invoice Date:  <?php echo $_POST['date_order'];?><br>
                                Due Date: <?php echo $_POST['due_date'];?>
                                <br /> <br /> <br /> <br />
                                Name: <?php  echo $_POST['order_name'];echo '<br>';?>
                                Address:<?php echo  $_POST['location'];echo '<br>';?>
                                
                            </td>
                           
                            <td id ="unpaid">
                           <H1> UNPAID</H1>
                            </td>
                           
                            
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                   <center> Description</center>
                </td>
                
                <td>
                   
                </td>
            </tr>
            
            
                
                <td>
                   
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Service
                </td>

                
                <td>
                    Price
                </td>
            </tr>
            
            <tr class="item">
                <td>
       <?php  var_dump($_POST['product_name'][$i]);
	   
	   array (
            array('product_name[$i]'=>'product_name[$i]')
)
				   
				   ?>
                
                <td>
                    $300.00
                </td>
            </tr>
            
            <tr class="item">
                <td>
                    Hosting (3 months)
                </td>
                
                <td>
                    $75.00
                </td>
            </tr>
            
            <tr class="item last">
                <td>
                    Domain name (1 year)
                </td>
                
                <td>
                    $10.00
                </td>
            </tr>
            
            <tr class="total">
                <td></td>
                
                <td>
                   Total: $385.00
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
